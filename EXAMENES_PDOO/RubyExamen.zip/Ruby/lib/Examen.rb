#encoding: utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.


module Examen
  
  require 'singleton'
  require_relative 'card_dealer'
  require_relative 'prize'
  require_relative 'prize_examen'
  require_relative 'bad_consequence'
  require_relative 'treasure_kind'
  require_relative 'monster'
  
  class Test
    include Singleton
    include NapakalakiGame
    
    @@contador=0
    
    def principal
      premioLevel = PrizeExamen.newOnlyLevels(5)
      premioTreasure = PrizeExamen.newOnlyTreasures(5)

      Test.instance.contabiliza
      puts Test.getContador
      puts "\n"
      CardDealer.instance.stats
      puts premioLevel
      puts premioTreasure
    end
    
    def self.getContador
      return @@contador
    end
    
    def contabiliza
      if @@contador < 10
         @@contador+=1
      end
    end
    
    puts Test.instance.principal
  end 
end
